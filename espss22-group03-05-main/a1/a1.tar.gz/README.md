# Assignment 1 :  Primzahlen Annäherung

## Lernziel
Datentypen, Operatoren, Ein/Ausgabe, Kontrollstrukturen, Arrays, Funktionen

## Ziel des Programms
Dieses Programm ermittelt Primzahlen mit Hilfe des Sieb des Eratosthenes und berechnet wie viele Primzahlen benötigt werden, um das Euler-Produkt der Riemannschen Zeta-Funktion ausrechnen zu können.

## Theorie
Für eine einfache Erklärung der Theorie empfehlen wir folgendes Video: [Riemannsche Vermutung](https://youtu.be/qeCqjJpqbls).
### Zeta-Funktion
Bereits Leonhard Euler hat einen Zusammenhang zwischen der Analysis und Diskreten Mathematik entdeckt, indem er herausfand dass die Grenzwerte einer bestimmten endlosen Reihe von Summanden gleich sind wie die eines endlosen Produkts.

Die Summe sieht dabei so aus:

```math
\begin{equation}
\frac{1}{1^s}+\frac{1}{2^s}+\frac{1}{3^s}+\frac{1}{4^s}...
\end{equation}
```

oder mathematischer:

```math
\begin{equation}
\sum_{n = 1}^{\infty} \frac{1}{n^s}
\end{equation}
```

Diese Funktion nannte er Zeta(s):

```math
\begin{equation}
\zeta(s) = \sum_{n = 1}^{\infty} \frac{1}{n^s}
\end{equation}
```

Er fand nun heraus, dass diese Reihe im unendlichen denselben Grenzwert anstrebt wie:

```math
\begin{equation}
\frac{1}{1-\frac{1}{2^s}}*\frac{1}{1-\frac{1}{3^s}}*\frac{1}{1-\frac{1}{5^s}}*\frac{1}{1-\frac{1}{7^s}}*\frac{1}{1-\frac{1}{11^s}}...
\end{equation}
```

oder mathematischer ausgedrückt, das Euler-Produkt der Zeta-Funktion:

```math
\begin{equation}
\zeta(s) = \prod_{p = Prime}^{\infty} \frac{1}{1-\frac{1}{p^s}}
\end{equation}
```

Es gilt also:

```math
\begin{equation}
\zeta(s) = \sum_{n = 1}^{\infty} \frac{1}{n^s} = \prod_{p = Prime}^{\infty} \frac{1}{1-\frac{1}{p^s}}
\end{equation}
```

### Sieb des Eratosthenes
Für die Verwendung der Euler-Produkt Zeta-Funktion müssen Primzahlen gefunden werden, diese ermitteln wir mit Hilfe des [Sieb des Eratosthenes](https://de.wikipedia.org/wiki/Sieb_des_Eratosthenes).
Der Sieb enthällt eine aufsteigende Liste aller natürlichen Zahlen beginnend mit der Zahl 2 und endet mit einer vorgegebenen Zahl welche definiert bis wie weit auf Primzahlen geprüft werden soll.
Der Algorithmus arbeitet wie folgt:
```
1. Finde nächste unmarkierte Zahl bis zum Limit.
2. Diese ist eine Primzahl.
3. Markiere alle nachfolgenden Vielfachen dieser Zahl.
4. Gehe zu Schritt 1.
```
Nehmen wir als Beispiel die Berechnung bis zur Zahl 20:
```
2 ist die erste unmarkierte Zahl, diese ist daher eine Primzahl.
Alle Vielfachen von 2 werden markiert (2, 4, 6, 8, 10, 12, 14, 16, 18, 20).
Bisher markierte Zahlen : 2, 4, 6, 8, 10, 12, 14, 16, 18, 20.

3 ist die nächste unmarkierte Zahl, diese ist daher eine Primzahl.
Alle Vielfachen von 3 werden markiert (3, 6, 9, 12, 15, 18).
Bisher markierte Zahlen : 2, 3, 4, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20.

5 ist die nächste unmarkierte Zahl, diese ist daher eine Primzahl.
Alle Vielfachen von 5 werden markiert (5, 10, 15, 20).
Bisher markierte Zahlen : 2, 3, 4, 5, 6, 8, 9, 10, 12, 14, 15, 16, 18, 20.

7 ist die nächste unmarkierte Zahl, diese ist daher eine Primzahl.
Alle Vielfachen von 7 werden markiert (7, 14).
Bisher markierte Zahlen : 2, 3, 4, 6, 7, 8, 9, 10, 12, 14, 15, 16, 18, 20.

11 ist die nächste unmarkierte Zahl, diese ist daher eine Primzahl.
Alle Vielfachen von 11 werden markiert (11).
Bisher markierte Zahlen : 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 18, 20.

13 ist die nächste unmarkierte Zahl, diese ist daher eine Primzahl.
Alle Vielfachen von 13 werden markiert (13).
Bisher markierte Zahlen : 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20.

17 ist die nächste unmarkierte Zahl, diese ist daher eine Primzahl.
Alle Vielfachen von 17 werden markiert (17).
Bisher markierte Zahlen : 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20.

19 ist die nächste unmarkierte Zahl, diese ist daher eine Primzahl.
Alle Vielfachen von 17 werden markiert (19).
Bisher markierte Zahlen : 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20.

Bis zum Limit (20) gibt es keine unmarkierten Zahlen mehr, der Algorithmus ist beendet mit den Primzahlen: 2, 3, 5, 7, 11, 13, 17, 19
```

## Aufgabenstellung
Zuerst wird eine Referenz Zeta(**2**) mit einer vom Benutzer festgelegten Anzahl an Summanden (max_n) mit der Zeta Funktion berechnet.
```math
\begin{equation}
\zeta(2) = \sum_{n = 1}^{max_n} \frac{1}{n^2}
\end{equation}
```

Danach soll das Programm mithilfe des Siebs des Eratosthenes berechnen, wie viele Primzahlen (min_p) mindestens benötigt werden, um sich mit der Euler-Produkt Zeta-Funktion an Zeta(**2**) annähern zu können. Das maximale Limit des Siebs wird ebenso vom Benutzer festgelegt.

Da Grenzwerte ins Unendliche gehen, muss auch ein Schwellwert welcher vom Benutzer eingegeben wird, berücksichtigt werden.

Mathematisch ausgedrückt:

```math
\begin{equation}
\prod_{p = Prime}^{min_p} \frac{1}{1-\frac{1}{p^2}} \ge \sum_{n = 1}^{max_n} \frac{1}{n^2} - Schwellwert
\end{equation}
```

### Beispielberechnung

Berechnen wir min_p beispielhaft mit folgenden Werten: max_n = 30; Limit des Sieb: 50; Schwellwert: 0.015.

Zuerst das Referenz Zeta abzüglich des Schwellwerts:
```math
\zeta(2) = \sum_{n = 1}^{30} \frac{1}{n^2} = \frac{1}{1^2}+\frac{1}{2^2}+\frac{1}{3^2}+\frac{1}{4^2}+...+\frac{1}{29^2}+\frac{1}{30^2} = 1.61215
```
```math
1.61215 - 0.015 = 1.59715
```
Bis zur Zahl 50 gibt es folgende Primzahlen: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47

Berechnen wir nun wie viele dieser Primzahlen in der Euler-Produkt Zeta-Funktion mindestens verwendet werden müssen, um unter Einhaltung des Schwellwertes auf eine Annäherung zu kommen.
```math
\prod_{p = Prime}^{??} \frac{1}{1-\frac{1}{p^2}} \ge 1.59715
```
```math
\prod_{p = Prime}^{1} \frac{1}{1-\frac{1}{p^2}} = \frac{1}{1-\frac{1}{2^2}} = 1.333333 \not{\ge} 1.59715
```
```math
\prod_{p = Prime}^{2} \frac{1}{1-\frac{1}{p^2}} = \frac{1}{1-\frac{1}{2^2}}*\frac{1}{1-\frac{1}{3^2}} = 1.50000 \not{\ge} 1.59715
```
```math
\prod_{p = Prime}^{3} \frac{1}{1-\frac{1}{p^2}} = \frac{1}{1-\frac{1}{2^2}}*\frac{1}{1-\frac{1}{3^2}}*\frac{1}{1-\frac{1}{5^2}} = 1.56250 \not{\ge} 1.59715
```
```math
\prod_{p = Prime}^{4} \frac{1}{1-\frac{1}{p^2}} = \frac{1}{1-\frac{1}{2^2}}*\frac{1}{1-\frac{1}{3^2}}*\frac{1}{1-\frac{1}{5^2}}*\frac{1}{1-\frac{1}{7^2}} = 1.59505 \not{\ge} 1.59715
```
```math
\prod_{p = Prime}^{5} \frac{1}{1-\frac{1}{p^2}} = \frac{1}{1-\frac{1}{2^2}}*\frac{1}{1-\frac{1}{3^2}}*\frac{1}{1-\frac{1}{5^2}}*\frac{1}{1-\frac{1}{7^2}}*\frac{1}{1-\frac{1}{11^2}} = 1.60834 \ge 1.59715
```
**Ergebnis**: Mit den ersten **5** Primzahlen wird eine Annäherung erreicht, diese lauten: **2, 3, 5, 7, 11**.

**Tipp**: Mit Wolfram Alpha können Sie die Berechnungen überprüfen: [Summen Zeta](https://www.wolframalpha.com/input?i2d=true&i=Sum%5BDivide%5B1%2CPower%5Bn%2C2%5D%5D%2C%7Bn%2C1%2C30%7D%5D), [Produkt Zeta](https://www.wolframalpha.com/input?i2d=true&i=Divide%5B1%2C1-Divide%5B1%2CPower%5B2%2C2%5D%5D%5D*Divide%5B1%2C1-Divide%5B1%2CPower%5B3%2C2%5D%5D%5D*Divide%5B1%2C1-Divide%5B1%2CPower%5B5%2C2%5D%5D%5D*Divide%5B1%2C1-Divide%5B1%2CPower%5B7%2C2%5D%5D%5D*Divide%5B1%2C1-Divide%5B1%2CPower%5B11%2C2%5D%5D%5D).

## Programmablauf
### Eingabe
* Das Programm liest zuerst die Anzahl an Summanden (max_n) welche für die Berechnung des Referenz Zeta benötigt werden ein:
```
number of summands: 
```
* Danach der Limit des Sieb:
```
limit of sieve: 
```
* Als letze Eingabe erfolgt die Größe des Schwellwerts:
```
size of threshold: 
```
Sollte eine falsche Eingabe getätigt werden, wird die Benutzeraufforderung für die jeweilige Eingabe wiederholt.

Erlaubte Eingaben:
* Summanden: 2 bis 2022 (es werden nur integer getestet).
* Sieb: 2 bis 2022 (es werden nur integer getestet).
* Schwellwert: 0.0002 bis 0.2 (es werden nur doubles getestet).

### Berechnung & Ausgabe
Als erstes werden folgende drei Ausgaben getätigt:
1. das referenz Zeta (ohne Schwellwert Abzug)
```
\nreference zeta: <zeta_r>\n
```
2. der behandelte Sieb und eine Trennlinie
```
\n
	2	3	0	5	0	7	0	0	0	\n
11	0	13	0	0	0	17	0	19	0	\n
0	0	23	0	0	0	0	0	29	0	\n
...
\n-------------------------------------------------------------------------\n
```
3. eine Auflistung der gefundenen Primzahlen
```
available primes: <prime prime ... >\n
```

Das Programm berechnet nun iterativ eine Annäherung.
Für jeden Versuch werden folgende Informationen ausgegeben:
1. eine Liste der bisher benutzten Primzahlen
```
\nusing primes: <prime prime ... >\n
```
2. die aktuelle Annäherung der Euler-Produkt Zeta-Funktion
```
current zeta: <zeta_ep>\n
```

Wenn eine Annäherung gefunden wurde, wird folgendes ausgegeben:
```
\nApproximation found!\n
You need the first <amount_primes> prime numbers to reach <zeta_r> with a threshold of <threshold>.\n
```
Sollte keine Annäherung gefunden werden (z.B. weil nicht genug Primzahlen), wird folgendes ausgegeben:
```
\nNo approximation found!\n
```
Das Programm beendet sich mit dem Return-Wert 0.

Beachten Sie folgende Hinweise und die Beispielausgaben:
* die Platzhalter <XX> sind durch entsprechende Werte zu ersetzen
* sämtliche Dezimalwerte sind auf 5 Nachkommastellen auszugeben
* sämtliche Dezimalwerte sind vom Typ **double**
* /n steht für neue Zeile
* Primzahlen in der Auflistung available und using werden mit einem Leerzeichen getrennt (auch nach der letzten Primzahl)
* Sieb:
* * markierte Zahlen werden mit 0 dargestellt
* * die einzelnen Werte in der Ausgabe sind mit einem Tabulator getrennt, auch der Letzte je Spalte (printf("%d\t"))
* * pro Zeile werden max. 10 Zahlen ausgegeben
* * die 1 wird nicht angezeigt (da der Sieb bei 2 beginnt)

### Beispielausgaben
```
number of summands: 30
limit of sieve: 50
size of threshold: 0.015

reference zeta: 1.61215

	2	3	0	5	0	7	0	0	0	
11	0	13	0	0	0	17	0	19	0	
0	0	23	0	0	0	0	0	29	0	
31	0	0	0	0	0	37	0	0	0	
41	0	43	0	0	0	47	0	0	0	
-------------------------------------------------------------------------
available primes: 2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 

using primes: 2 
current zeta: 1.33333

using primes: 2 3 
current zeta: 1.50000

using primes: 2 3 5 
current zeta: 1.56250

using primes: 2 3 5 7 
current zeta: 1.59505

using primes: 2 3 5 7 11 
current zeta: 1.60834

Approximation found!
You need the first 5 prime numbers to reach 1.61215 with a threshold of 0.01500.
```
```
number of summands: 1
number of summands: 5000
number of summands: 10
limit of sieve: 133
size of threshold: 2.0
size of threshold: 0.3
size of threshold: 0.005

reference zeta: 1.54977

	2	3	0	5	0	7	0	0	0	
11	0	13	0	0	0	17	0	19	0	
0	0	23	0	0	0	0	0	29	0	
31	0	0	0	0	0	37	0	0	0	
41	0	43	0	0	0	47	0	0	0	
0	0	53	0	0	0	0	0	59	0	
61	0	0	0	0	0	67	0	0	0	
71	0	73	0	0	0	0	0	79	0	
0	0	83	0	0	0	0	0	89	0	
0	0	0	0	0	0	97	0	0	0	
101	0	103	0	0	0	107	0	109	0	
0	0	113	0	0	0	0	0	0	0	
0	0	0	0	0	0	127	0	0	0	
131	0	0	
-------------------------------------------------------------------------
available primes: 2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97 101 103 107 109 113 127 131 

using primes: 2 
current zeta: 1.33333

using primes: 2 3 
current zeta: 1.50000

using primes: 2 3 5 
current zeta: 1.56250

Approximation found!
You need the first 3 prime numbers to reach 1.54977 with a threshold of 0.00500.
```
```
number of summands: 1000
limit of sieve: 12
size of threshold: 0.0002

reference zeta: 1.64393

	2	3	0	5	0	7	0	0	0	
11	0	
-------------------------------------------------------------------------
available primes: 2 3 5 7 11 

using primes: 2 
current zeta: 1.33333

using primes: 2 3 
current zeta: 1.50000

using primes: 2 3 5 
current zeta: 1.56250

using primes: 2 3 5 7 
current zeta: 1.59505

using primes: 2 3 5 7 11 
current zeta: 1.60834

No approximation found!
```

## Spezifikation
* Deadline: 22.04.2022 23:59
* Abgabe: a1.c

## Bewertung
| Kategorie	 | Punkte |
| --------- |:------:|
| Funktionaliät	|   16   |
| Doku und Still |   3    |
| Programmstruktur |   3    |
| Robustheit |   1    |
