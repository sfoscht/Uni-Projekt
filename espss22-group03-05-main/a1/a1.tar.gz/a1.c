#include <stdio.h>
#include <math.h>

// Limit des Siebes wird festgelegt-------------
int readInput(char* message)
{
  int input = 0;
  while (1)
  {
    printf("%s", message);
    scanf("%i", &input);
    if (input >= 2 && input <= 2022)
    {
      return input;
    }
  }
}
//--------------------------
double sizeOfThreshold()
{
  double input = 0;
  while (1)
  {
    printf("size of threshold: ");
    scanf("%lf", &input);
    if (input >= 0.0002 && input <= 0.2)
    {
      return input;
    }
  }
}

void printPrimes(const int limit)
{
  int count = 0;
  int primes[limit];
  int indexCounter = 0;

  for (int current = 1; current <= limit; current++){
    count = 0;

    for (int index = 2; index <= current / 2; index++){
      if (current % index == 0){
        count++;
        break;
      }
    }

    if ((current - 1) % 10 == 0) printf("\n");

    if (current == 1) printf(" 	");
    else if (count == 0){
      printf("%d	", current);
      primes[indexCounter++] = current;
    }
    else printf("0	");
  }

  printf("\n-------------------------------------------------------------------------\n");
  printf("available primes: ");

  int arrayLength = sizeof(primes);
  for (int i = 0; i <= arrayLength; i++){
    printf("%i\0", primes[i]);
  }
}

  double current_zeta ()
  {



  }

int main(void)
{
  const int summandCount = readInput("number of summands: ");
  const int limitOfSieve = readInput("limit of sieve: ");
  const double threshold = sizeOfThreshold();

  double referenceZeta = 0;
  for (int maxN = 1; maxN <= summandCount; maxN++){
    referenceZeta += (1 / pow(maxN, 2));
  }
  // referenceZeta -= threshold;

  printf("\nreference zeta: %.5lf\n", referenceZeta);

  printPrimes(limitOfSieve);
  printf("\n");

  return 0;
}
